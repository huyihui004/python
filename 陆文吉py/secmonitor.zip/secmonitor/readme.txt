# secmonitor 说明文档

1.目录结构:
secmonitor---secmonitor--------①创建守护进程
    |              |
    |              |-----------②动态加载扫描模块 
    |              |  
    |              |-----------③文件变动实时监控
    |
    |
    |-----moudles---NoticeHandler.py--------①加载配置
    |        |             |
    |        |             |----------------②日志记录,邮件告警，发送到日志服务器
    |        |             |
    |        |             |----------------③执行shell命令，获取本机IP
    |        |
    |        |
    |        |---ScanFirewallHandler.py---------防火墙状态及规则变更监控
    |        | 
    |        |---ScanNetworkHandler.py----------网络连接实时监控
    |        | 
    |        |---ScanWebShellHandler.py---------webshell实时监控
    |        |
    |        |---ScanFileHandler.py-------------系统关键目录监控
    |        |
    |        |---ScanNormalHandler.py-----------常规项监控
    |        |
    |        |---Scan...Handler.py--------------新增的监控项
    |
    |
    |-----conf----------secmonitor.conf---------程序所需的文件配置目录
    |
    |
    |-----log-----------access.log--------------记录执行结果及错误日志

2.安装方式
把该目录解压/usr/local目录下.
创建软连接 
ln -s /usr/local/secmonitor/secmonitor /usr/sbin/secmonitor

3.启动方式
已root权限执行，加入到sudo可执行中
启动
sudo secmonitor start
查看状态
sudo secmonitor status
关闭
sudo secmonitor stop

4.其他
Linux ≥ 2.6.13
需安装lsof
跳板机上需额外安装python模块 paramiko，pexpect
