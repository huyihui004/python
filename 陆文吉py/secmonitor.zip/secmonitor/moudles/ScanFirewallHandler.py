#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Date    : 2015-11-12 18:01:32
# @Author  : veng (veng6115@gmail.com)
# @Link    : http://www.veng.cc


import threading
import time
import copy
import traceback


class ScanFirewallHandler(threading.Thread):

    """ monitor network connection """

    def __init__(self, (event_queue, noticehandler)):
        super(ScanFirewallHandler, self).__init__()
        self.daemon = False
        self.whiteiplist = []
        self.whitedict = {}
        self.mailuser = []
        self.queue, self.nt_hd = (event_queue, noticehandler)
        self.time = 25
        self.splunk_network_port = 30001
        self.nt_hd.log('ScanFirewallHandler', 'step in init.')

    def run(self):

        sshcommand = "%s|%s|%s|%s|%s" % (
            'netstat -lntp',
            'grep sshd',
            'grep 0.0.0.0',
            "awk '{print $4}'",
            "awk -F ':' '{print $2}'")

        output = self.nt_hd.getcommanddata(sshcommand)
        if not output:
            self.nt_hd.senddata(
                'sshd    norunning.', self.splunk_network_port)
        else:
            command = "iptables -nL INPUT|grep 'dpt:%s'" % (output[0])
            datalist = self.nt_hd.getcommanddata(command)
            if datalist:
                self.nt_hd.log('firewall', str(datalist))
                for line in datalist:
                    self.nt_hd.senddata(
                        'sshd    ' + line, self.splunk_network_port)
            else:
                pass

        # set init data, to know first time step in
        retlist_old = ['1']
        while True:
            try:
                retlist_new = []
                command = "iptables -nL INPUT|egrep -v 'WARNING|INPUT|target'"
                retlist_new = self.nt_hd.getcommanddata(command)

                if (not retlist_old) and retlist_new:
                    self.nt_hd.senddata(
                        'iptables    start.', self.splunk_network_port)
                elif retlist_old and retlist_old != ['1']:
                    netdatalist = list(set(retlist_new) - set(retlist_old))
                    if netdatalist:
                        self.nt_hd.log(
                            'firewall', 'senddata' + str(netdatalist))
                        for line in netdatalist:
                            self.nt_hd.senddata(
                                'iptables    ' + line, self.splunk_network_port)
                    elif not retlist_new:
                        self.nt_hd.senddata(
                            'iptables    norunning.', self.splunk_network_port)
                # juge first step in ,iptables status.
                elif (not retlist_new) and retlist_old == ['1']:
                    self.nt_hd.senddata(
                        'iptables    norunning.', self.splunk_network_port)
                retlist_old = copy.deepcopy(retlist_new)
            except:
                msg = traceback.format_exc()
                self.nt_hd.log('ScanFirewallHandler', 'errormsg: %s' % str(msg))
                break
            time.sleep(self.time)
