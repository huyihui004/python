#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Date    : 2015-11-12 18:26:23
# @Author  : veng (veng6115@gmail.com)
# @Link    : http://www.veng.cc


import os
import time
import socket
import re
import ConfigParser

import logging

import signal

import gc

import smtplib
try:
    from email.mime.text import MIMEText
    from email.mime.multipart import MIMEMultipart
    # from email.mime.image import MIMEImage
except:
    from email.MIMEText import MIMEText
    from email.MIMEMultipart import MIMEMultipart

try:
    import hashlib
except ImportError:
    import md5 as hashlib


class SendMail:

    """ 发送Email模块, 用户列表请使用 list类型,附件也使用 list类型 """

    def __init__(self, host, username, password, port=25):
        self.host = host
        self.username = username
        self.password = password
        self.port = port

    def do_connect(self):
        self.smtp = smtplib.SMTP()
        try:
            self.smtp.connect(self.host + ':' + str(self.port))
            self.smtp.login(self.username, self.password)
        except:
            return False
        return True

    def make_email_body(self):
        to_string = ''
        if isinstance(self.send_to, list):
            to_string = ','.join(self.send_to)
        else:
            to_string = self.send_to
        self.email_body = MIMEMultipart()
        # 处理头部
        self.email_body['From'] = self.username
        self.email_body['To'] = to_string
        self.email_body['Subject'] = self.subject
        # 处理正文
        message = MIMEText(self.message_body, 'html', 'utf-8')
        self.email_body.attach(message)
        # 处理附件
        if not self.attach_files:
            return
        for path in self.attach_files:
            if os.path.exists(path):
                att = MIMEText(open(path, 'rb').read(), 'base64', 'utf-8')
                att["Content-Type"] = 'application/octet-stream'
                att["Content-Disposition"] = 'attachment; filename="%s"' % \
                    os.path.split(path)[1]
                self.email_body.attach(att)

    def do_send(self, send_to, subject, message_body, attach_files=[]):
        self.send_to = send_to
        self.subject = subject
        self.message_body = message_body
        self.attach_files = attach_files
        self.make_email_body()
        try:
            self.smtp.sendmail(
                self.username, self.send_to, self.email_body.as_string())
            return 1
        except smtplib.SMTPException, e:
            print e
            return 0

    def do_close(self):
        self.smtp.quit()


class NoticeHandler:

    """log,email,splunk recv moudle"""

    def __init__(self, path, splunk_ip='203.14.188.243'):
        self.dbpath = os.path.join(path, '..', '.secmonitor.db')
        self.logfile = os.path.join(path, '..', 'logs', 'monitor.log')
        self.confpath = os.path.join(path, '..', 'conf', 'secmonitor.conf')
        self.splunkip = splunk_ip
        self.broot = self.getbroot()
        self.whitedict, self.whiteiplist, self.mailuserlist = self.loadconf()
        if not self.mailuserlist:
            self.mailuserlist = ['luwj@13322.com']

        self.loghander = self.Logger(self.logfile)

    def loadconf(self):
        '''加载配置文件'''

        whitedict = {}
        whiteiplist = []
        mailuserlist = []
        ip = self.getip()
        cf = ConfigParser.ConfigParser()
        if os.path.exists(self.confpath):
            try:
                # os.chmod(self.confpath, stat.S_IREAD)
                cf.read(self.confpath)
            except:
                pass
            opts = cf.options("mail")
            for opt in opts:
                mailuserlist = eval(cf.get("mail", opt))
            opts = cf.options("ip")
            for opt in opts:
                whitedict[opt] = eval(cf.get("ip", opt))
            opts = cf.options("whiteip")
            for opt in opts:
                whiteiplist = eval(cf.get("whiteip", opt))

            if ip in whitedict.keys():
                whitedict = whitedict[ip]

        return whitedict, whiteiplist, mailuserlist

    def getfilesize(self, filepath):
        '''get file size'''
        if os.path.exists(filepath):
            return os.stat(filepath).st_size
        else:
            return -1

    def getfilemtime(self, filepath):
        '''get file mtime'''

        return os.stat(filepath).st_mtime

    def getallfilepath(self, pathlist):
        '''get all file path and mtime'''

        retlist = []
        h_file = re.compile(r".*", re.IGNORECASE)

        for path in pathlist:
            if os.path.isfile(path):
                curfilemtime = time.strftime(
                    '%Y-%m-%d %H:%M:%S',
                    time.localtime(os.stat(path).st_mtime))
                tmpdict = {}
                tmpdict['path'] = path
                tmpdict['mtime'] = curfilemtime
                retlist.append(tmpdict)
            else:
                for root, dirs, files in os.walk(path):
                    for name in files:
                        match = h_file.search(name)
                        if match is not None:
                            curfile = os.path.join(root, name)
                            if os.path.exists(curfile):
                                curfilemtime = time.strftime(
                                    '%Y-%m-%d %H:%M:%S',
                                    time.localtime(os.stat(curfile).st_mtime))
                                tmpdict = {}
                                tmpdict['path'] = curfile
                                tmpdict['mtime'] = curfilemtime
                                retlist.append(tmpdict)
        return retlist

    def getprocpid(self):
        '''get process pid'''

        return os.getpid()

    def recover(self, obj):
        ''' reclver object '''

        del obj
        gc.collect()

    def kill(self, pid):
        '''close process'''

        try:
            while True:
                os.kill(pid, signal.SIGTERM)
                time.sleep(0.1)
        except OSError, err:
            err = str(err)
            # if err.find("No such process") > 0:
            #     pidfile = os.path.join(getcurpath(), '..', '.monitor.pid')
            #     if os.path.exists(self.pidfile):
            #         os.remove(self.pidfile)
            # else:
            #     print err
            #     sys.exit(1)

    def getfiledata(self, filepath):
        '''get file data'''

        filecontent = ''
        fp = open(filepath)
        while True:
            lines = fp.readlines(100000)
            if not lines:
                break
            for line in lines:
                filecontent = filecontent + line
        fp.close()
        return filecontent

    def getfilehash(self, filepath):
        '''get file md5'''
        f = None
        try:
            f = open(filepath, 'rb')
            md5obj = hashlib.md5()
            md5obj.update(f.read())
            hash = md5obj.hexdigest()
            return hash
        except:
            return ''
        finally:
            if f is not None:
                f.close()

    def getbroot(self):
        '''get current running user. '''

        gid = os.getegid()
        uid = os.geteuid()
        broot = False
        if gid == 0 or uid == 0:
            broot = True
        return broot

    def isallowcommandline(self, command):
        '''get if allowed run command'''

        bret = True
        whitecommand = [
            'netstat', 'lsof', 'iptables', 'find', 'ps', 'id', 'file']
        cc = re.split(';|&&|\|\|', command)
        curcommand = []
        for line in cc:
            curcommand.append(re.split(' |\|', line)[0])

        if set(curcommand) - set(whitecommand):
            bret = False

        return bret

    def getcommanddata(self, command):
        ''' get command excute result '''

        retlist_new = []

        if not self.isallowcommandline(command):
            return retlist_new

        # if not self.broot:
        #     command = '%s %s' % ('sudo', command)
        output = os.popen(command).read()
        if output:
            retlist_new = output[:-1].split('\n')

        return retlist_new

    def log(self, moudlename, datastr):
        '''datastr current data, moudlename step in moudle.'''

        # if not os.path.exists(self.logfile):
        #     os.mknod(self.logfile)
        #     try:
        #         os.chmod(self.logfile, stat.S_IREAD + stat.S_IWRITE)
        #     except:
        #         pass

        # fp = open(self.logfile, 'a')

        # curtime = time.strftime('%Y-%m-%d %H:%M:%S',
        #                         time.localtime(time.time()))
        # msg = "[%s] [%s] %s\n\n" % (curtime, moudlename, datastr)
        # fp.write(msg)
        # fp.close()
        msg = ' [%s]\t%s\n\n' % (moudlename, datastr)
        self.loghander.info(msg)

    def senddata(self, msg, recvport=10001):
        ''' send data to splunk server '''

        addr = (self.splunkip, recvport)
        bret = True
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            data = '<attr> %s' % (msg)
            s.sendto(data, addr)
            s.close()
        except Exception, e:
            self.log('errormsg', str(e))
            bret = False
        return bret

    def sendmail(self, datalist, bwebshelldata):
        '''获取邮件正文'''

        self.log('testmail', str(self.mailuserlist))

        MAIL_STYLE = u"<style type=\"text/css\">\
                *{font-family:Tahoma, Arial, Helvetica, Sans-serif;} \
                table{width:700px;margin:0px auto;font:Georgia 11px;\
                    font-size:12px;color:#333333;text-align:center;\
                    border-collapse:collapse;}\
                table td{border:1px solid #999;height:22px;}\
                caption{text-align:center;font-size:12px;font-weight:bold;\
                    margin:0 auto;}\
                tr.t1 td {background-color:#fff;}\
                tr.t2 td {background-color:#eee;}\
                tr.t3 td {background-color:#ccc;}\
                th,tfoot tr td{font-weight:bold;text-align:center;\
                    background:#c5c5c5;}\
                th{line-height:30px;height:30px;}\
                tfoot tr td{background:#fff;line-height:26px;height:26px;}\
                thead{border:1px solid #999;}\
                thead tr td{text-align:center;}\
                # page{text-align:center;float:right;}\
                # page a,#page a:visited{width:60px;height:22px;\
                    line-height:22px;border:1px black solid;display:block;\
                    float:left;margin:0 3px;background:#c9c9c9;\
                    text-decoration:none;}\
                # page a:hover{background:#c1c1c1;text-decoration:none;}\
                .grayr {padding:2px;font-size:11px;background:#fff;\
                float:right;}\
                .grayr a {padding:2px 5px;margin:2px;color:#000;\
                    text-decoration:none;;border:1px #c0c0c0 solid;}\
                .grayr a:hover {color:#000;border:1px orange solid;}\
                .grayr a:active {color:#000;background: #99ffff}\
                .grayr span.current {padding:2px 5px;\
                font-weight:bold;margin:2px;\
                    color: #303030;background:#fff;border:1px orange solid;}\
                .grayr span.disabled {padding:2px 5px;margin:2px;color:#797979;\
                    background: #c1c1c1;border:1px #c1c1c1 solid;}\
                </style>"
        if bwebshelldata:
            title = u'webshell实时监控'
        else:
            title = u'网络连接实时监控'

        MSG_TITLE = u'[HHLY] %s-%s [%s]' % (self.getip(),
                                            title,
                                            time.strftime('%Y-%m-%d %H:%M:%S'))
        mail_msg = u''
        MAIL_BODY = u''
        if bwebshelldata:
            MAIL_BODY = u'<table><thead><tr><tr><th>filename</th>\
                        <th>excutematch</th><th>exmatchtimes</th>\
                        <th>writematch</th><th>wrmatchtimes</th></tr><thead>'

            nlist = ['filename', 'excutematch',
                     'excutenum', 'writematch', 'writenum']
        else:
            MAIL_BODY = u'<table><thead><tr><tr><th>procname</th><th>user</th>\
                        <th>pid</th><th>cmd</th><th>connection</th></tr><thead>'
            nlist = ['procname', 'user', 'pid', 'cmd', 'connection']

        for line in datalist:
            if isinstance(line, dict):
                mail_msg += u"<tr>"
                for name in nlist:
                    mail_msg += u"<td>%s</td>" % line[name]
                mail_msg += u"</tr>"
            else:
                mail_msg += u"<tr>%s</tr>" % str(line)
        sendmail = SendMail('mail.7road.com', 'alarm@7road.com', '7road.com')
        msg = MAIL_STYLE + MAIL_BODY + mail_msg + "</table>"
        try:
            if sendmail.do_connect():
                sendmail.do_send(self.mailuserlist, MSG_TITLE, msg)
                sendmail.do_close()
            else:
                self.log('email', 'connect error.' + str(datalist))
        except Exception, e:
            msg = '%s send mail error,msg=%s' % (MSG_TITLE, e)
            self.log('email', msg)

    def getip(self, argv=None):
        '''get server ip'''

        cmd = ('''/sbin/ifconfig |grep Bcast|awk -F : '{print $2}'|
            awk '{print $1}'|egrep -v '^10|^172|^192'|head -1''')
        output = os.popen(cmd).read()
        try:
            ip = output.split()[0]
        except:
            cmd = (
                '''/sbin/ifconfig |grep Bcast|awk -F : '{print $2}'|
                awk '{print $1}'|head -1''')
            output = os.popen(cmd).read()
            ip = output.split()[0]
        return ip

    class Logger(logging.Logger):

        """ log
        >>> logger = Logger('c:\\log.txt')
        >>> logger.info('test')
        >>> del logger
        """

        def __init__(self, name):
            logging.Logger.__init__(self, name, logging.NOTSET)

            self.hdlr = logging.FileHandler(name)
            formatter = logging.Formatter("[%(asctime)s] %(message)s",
                                          "%Y-%m-%d %H:%M:%S")
            self.hdlr.setFormatter(formatter)

            self.addHandler(self.hdlr)

            self.setLevel(logging.NOTSET)
            return

        def close(self):
            self.hdlr.flush()
            self.hdlr.close()
            self.removeHandler(self.hdlr)

        def __del__(self):
            self.close()
