#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Date    : 2015-12-01 17:01:32
# @Author  : veng (veng6115@gmail.com)
# @Link    : http://www.veng.cc


import threading
import time
import traceback
try:
    import sqlite3
except:
    # from pysqlite2 import dbapi2 as sqlite3
    pass


class ScanFileHandler(threading.Thread):

    """ monitor system file hash """

    def __init__(self, (event_queue, noticehandler)):
        super(ScanFileHandler, self).__init__()
        self.daemon = False
        self.queue, self.nt_hd = (event_queue, noticehandler)
        self.sleeptime = 60
        self.splunk_recv_port = 30005
        self.dbpath = self.nt_hd.dbpath
        self.check_pathlist = ['/bin', '/sbin', '/usr/bin', '/usr/sbin',
                               '/usr/local/sbin', '/usr/local/bin',
                               '/lib', '/usr/lib', '/usr/local/lib',
                               '/etc/passwd', '/etc/shadow', '/etc/ssh/',
                               '/etc/pam.d']
        self.check_64_pathlist = ['/lib64', '/usr/lib64', '/usr/local/lib64']
        self.nt_hd.log('ScanFileHandler', 'step in init.')
        self.excutetime = '20'

    def run(self):
        try:
            bexcute = True
            _debug = False
            systype = self.nt_hd.getcommanddata('file /sbin/init')[0].split()[2]
            if '64-bit' == systype:
                self.check_pathlist += self.check_64_pathlist
        except:
            msg = traceback.format_exc()
            self.nt_hd.log('ScanFileHandler', msg)
        while True:
            curhour = time.strftime("%H", time.localtime(time.time()))
            if _debug or (curhour == self.excutetime and bexcute):
                try:
                    curtime = time.localtime(time.time())
                    SqlOption = self.sqlOption(self.dbpath,
                                               self.nt_hd,
                                               self.splunk_recv_port)
                    SqlOption.InitDB()
                    SqlOption.CreateTable(curtime)
                    lasttable = SqlOption.GetLastTableName()
                    SqlOption.NewHash(curtime, lasttable, self.check_pathlist)
                    time.sleep(1)
                    SqlOption.TableCompareHash()

                    self.nt_hd.recover(SqlOption)
                except:
                    msg = traceback.format_exc()
                    self.nt_hd.log('ScanFileHandler', 'errormsg=%s' % str(msg))
                    break
                bexcute = False
                _debug = False
            elif curhour != self.excutetime:
                bexcute = True

            time.sleep(self.sleeptime)

    class sqlOption:

        """sqllite manager"""

        def __init__(self, dbname, nt_hd, splunk_recvport):
            self.dbname = dbname
            self.nt_hd = nt_hd
            self.splunk_recvport = splunk_recvport

        def TableCompareHash(self):
            '''file hash compare'''
            conn = sqlite3.connect(self.dbname)
            cur = conn.cursor()
            try:
                cur.execute("SELECT count(*) FROM tablelist")
            except:
                self.nt_hd.log('ScanFileHandler', 'None data in database')
                return
            res = cur.fetchall()
            rowcount = int(res[0][0])
            if rowcount < 2:
                self.nt_hd.log('ScanFileHandler', 'Hash less then 2 row.')
                return
            elif rowcount > 2:
                sql = '''SELECT tablename, id FROM tablelist
                         ORDER BY id ASC limit 0, %d''' % (rowcount - 2)
                cur.execute(sql)
                res = cur.fetchall()
                for i in range(len(res)):
                    droptb_sql = 'DROP TABLE  %s' % res[i][0]
                    cur.execute(droptb_sql)
                    conn.commit()
                    dropdata_sql = 'DELETE FROM tablelist WHERE id=%d' % int(
                        res[i][1])
                    cur.execute(dropdata_sql)
                    conn.commit()
            cur.execute(
                "SELECT tablename FROM tablelist ORDER BY id DESC LIMIT 0,2")
            res = cur.fetchall()
            tb1 = res[0][0]
            tb2 = res[1][0]
            sql = '''SELECT *,'%s' AS TableName FROM %s as t1
                    WHERE NOT EXISTS(SELECT * FROM %s as t2
                    WHERE t1.filename=t2.filename AND t1.hash=t2.hash )
                    UNION SELECT *,'%s' AS TableName FROM %s as t1 WHERE
                    NOT EXISTS(SELECT * FROM %s as t2
                    WHERE t1.filename=t2.filename
                    AND t1.hash=t2.hash )''' % (
                'newfile', tb1, tb2, 'removefile', tb2, tb1)

            cur.execute(sql)
            res = cur.fetchall()
            if len(res) > 0:
                for line in res:
                    data = ',%s' % ','.join(list(line)[1:])
                    self.nt_hd.senddata(data, self.splunk_recvport)
                    self.nt_hd.log('ScanFileHandler', str(line))
            cur.close()
            conn.close()

        def GetLastTableName(self):
            conn = sqlite3.connect(self.dbname)
            cur = conn.cursor()
            cur.execute(
                "SELECT tablename FROM tablelist ORDER BY id DESC")
            res = cur.fetchall()
            cur.close()
            conn.close()
            if len(res) == 0:
                return ''
            else:
                return res[0][0]

        def CreateTable(self, curtime):
            '''create table'''
            tbname = 'hashtable_' + time.strftime('%Y_%m_%d_%H_%M_%S', curtime)
            conn = sqlite3.connect(self.dbname)
            cur = conn.cursor()
            sql = "INSERT INTO tablelist values(?,?)"
            data = (None, tbname)
            cur.execute(sql, data)
            sql = '''CREATE TABLE  %s (id  INTEGER, fileName  TEXT,mtime DATETIME,
                hash NVARCHAR(32), createDate DATETIME,
                PRIMARY KEY (id))''' % tbname
            cur.execute(sql)
            sql = 'CREATE INDEX  %s ON  %s (filename ASC)' % (
                tbname + "_filename", tbname)

            cur.execute(sql)
            conn.commit()
            cur.close()
            conn.close()

        def NewHash(self, curtime, tblast, path_list):
            '''create file hash'''
            curtime = time.strftime('%Y-%m-%d %H:%M:%S', curtime)
            starttime = time.clock()
            conn = sqlite3.connect(self.dbname)
            cur = conn.cursor()

            sql = '''INSERT INTO %s values(?,?,?,?,?)''' % (tblast)

            pathlist = self.nt_hd.getallfilepath(path_list)
            count = len(pathlist)
            for line in pathlist:
                filehash = self.nt_hd.getfilehash(line['path'])
                data = (None, line['path'], line['mtime'], filehash, curtime)
                cur.execute(sql, data)

            conn.commit()
            cur.close()
            conn.close()
            endtime = time.clock()
            msg = 'time used: %s\tfiles: %s' % (
                str(endtime - starttime), str(count))
            self.nt_hd.log('ScanFileHandler', msg)

        def InitDB(self):
            '''init table'''
            conn = sqlite3.connect(self.dbname)
            cur = conn.cursor()
            sql = '''SELECT count(*) FROM sqlite_master WHERE type='table'
                     AND name="tablelist"'''
            cur.execute(sql)
            res = cur.fetchall()
            __rowcount = int(res[0][0])
            if __rowcount == 0:
                sql = '''CREATE TABLE tablelist (id  INTEGER,
                    tableName  TEXT, PRIMARY KEY (id ASC))'''
                cur.execute(sql)
                conn.commit()
            cur.close()
            conn.close()
