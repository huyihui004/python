#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Date    : 2015-11-12 17:50:32
# @Author  : veng (veng6115@gmail.com)
# @Link    : http://www.veng.cc

import re
import time
import itertools
import threading
import traceback


class ScanWebShellHandler(threading.Thread):

    """ webshell scan """

    def __init__(self, (event_queue, noticehandler)):
        super(ScanWebShellHandler, self).__init__()
        self.queue, self.nt_hd = (event_queue, noticehandler)
        self.daemon = False
        self.splunk_network_port = 30003
        self.sleeptime = 0.1
        self.filemaxsize = 20
        self.CodeRule = (r'''(?ms)<\?.*?\?>|<%.*?%>|<script\s+runat\s?=\s?"\s?server\s?"\s?>.*?</\s?script\s?>
            ''')
        self.RemarkRule = (r'''(?ms)""[^""]*""|/\*.*?\*/|[^:|'|\\|\}]//.*?$''')
        self.ShellRuleEX = (r'''[^.]\bExecute\b|JScript\.Encode|\bserver.execute\s+request|\bexecute\s+request|\beval\s+request|\beval_r\s+request|\bExecuteGlobal\s+request|\bExecute\s+Session|\bexecute\s*\(+\s*request|\beval\s*\(+\s*request|\beval_r\s*\(+\s*request|\bExecuteGlobal\s*\(+\s*request|\bExecute\s*\(+\s*Session|\s*'\s*:\s*eval|\bServer.CreateObject\s*\(\s*""ScriptControl""\s*\)|\bSystem.Reflection.Assembly.Load|\beval\s*\(+\s*\$|\beval_r\s*\(+\s*\$|\bassert\s*\(+\s*\$|`\$_Request\[.*`|`\$_GET\[.*`|`\$_POST\[.*`|\.ExecuteStatement\s*\(|\bnew\s+WebAdmin2Y|\beval\s*\(\s*@?base64_decode\s*\(|\beval\s*\(\s*@?gzuncompress\s*\(\s*@?base64_decode\(|\binclude.*(\.jpg|\.gif|\.png|\.bmp|\.txt)|\brequire_once.*(\.jpg|\.gif|\.png|\.bmp|\.txt)|\brequire.*(\.jpg|\.gif|\.png|\.bmp|\.txt)|\bexecute\s*\(+\s*\w+\s*\(+.*\s*\)|\bshell_exec\b|\bpassthru\s*\(|\bwscript\.shell\b|\bShell\.Application\b|\bVBScript\.Encode\b|\bxp_cmdshell\b|\bproc_open\b|\bSystem\.Net\.Sockets\b|\bSystem\.Diagnostics\b|\bSystem\.DirectoryServices\b|\bSystem\.ServiceProcess\b|\bnew\s+Socket\b|\bSystem\.Reflection\.Assembly\.Load\(Request\.BinaryRead\b|\bRuntime\.getRuntime\(\)\.exec\b|clsid:72C24DD5-D70A-438B-8A42-98424B88AFB8|clsid:13709620-C279-11CE-A49E-444553540000|clsid:0D43FE01-F093-11CF-8940-00A0C9054228|clsid:F935DC22-1CF0-11D0-ADB9-00C04FD58A0B|\bLANGUAGE\s*=\s*[""]?\s*(vbscript|jscript|javascript).encode\b|木马|小马|大马|提权|旁注|挂马|'?e'?\.?'?v'?\.?'?a'?\.?'?l'|\becho\s+`\s*\$.*`
        ''')
        self.ShellRuleWF = (r'''\bcopy\s*\(\s*\$_FILES|\bmove_uploaded_file\s*\(|\.CreateTextFile\s*\(|\.OpenTextFile\s*\(|\.SaveToFile\s+|\bSystem\.IO\.StreamWriter\b|\bfwrite\s*\(|\bRequest.Files[0].SaveAs|\bnew\s+BufferedWriter
        ''')
        self.nt_hd.log('ScanWebShellHandler', 'step in init.')

    def run(self):

        datalist = []
        namelist = [
            'filename', 'excutematch', 'excutenum', 'writematch', 'writenum']
        while True:
            try:
                if self.queue.empty() and datalist:
                    sendlist = []
                    # remove repeat data, create new file will have 2 results
                    for k, g in itertools.groupby(datalist):
                        sendlist.append(k)

                    self.nt_hd.log('webshell', str(sendlist))
                    bsendmail = False
                    for line in sendlist:
                        msg = ''
                        for name in namelist:
                            msg += ',%s' % line[name]
                        self.nt_hd.log('webshell', msg)
                        bret = self.nt_hd.senddata(
                            msg, self.splunk_network_port)
                        self.nt_hd.log('webshell', 'status.' + str(bret))
                        if not bret:
                            bsendmail = True
                    if bsendmail:
                        self.nt_hd.log('webshell', 'step in sendmail.')
                        self.nt_hd.sendmail(sendlist, True)
                    datalist = []
                elif not self.queue.empty():
                    event = self.queue.get()
                    if (event.pathname and not event.dir and
                            self.checkfiletype(event)):
                        filesize = self.nt_hd.getfilesize(event.pathname)
                        if (filesize / (1024 * 1024) < self.filemaxsize and
                                filesize > 0):
                            tmpdict = self.scan(event.pathname)
                            if tmpdict != {}:
                                datalist.append(tmpdict)
            except:
                msg = traceback.format_exc()
                self.nt_hd.log('ScanWebShellHandler', 'errormsg=%s' % str(msg))
                break

            time.sleep(self.sleeptime)

    def checkfiletype(self, event):
        '''check file type'''

        checklist = ['.jpg', '.bmp', '.gif', '.png', '.txt', '.jsp', '.php']
        if event.name[-4:].lower() in checklist:
            return True
        else:
            return False

    def scan(self, filepath):
        '''scan'''

        scanretdict = {}
        filecontent = self.nt_hd.getfiledata(filepath)

        # Uncomment
        pattern = re.compile(r"%s" % self.RemarkRule, re.IGNORECASE)
        _content = pattern.sub('', filecontent)

        # Get Code
        pattern = re.compile(r"%s" % self.CodeRule, re.IGNORECASE)
        matchs = pattern.finditer(_content)
        mlist = list(matchs)
        num = len(mlist)

        _code = ''
        if num > 0:
            for m in mlist:
                _code += m.group()

            pattern = re.compile(r"%s" % self.ShellRuleEX, re.IGNORECASE)
            match = pattern.finditer(_code)
            mlist = list(match)
            enum = len(mlist)

            excutematchstr = ''
            if enum > 0:
                for m in mlist:
                    excutematchstr += m.group()[0:30] + '<br>'

            scanretdict['excutenum'] = str(enum)
            scanretdict['excutematch'] = excutematchstr

            pattern = re.compile(r"%s" % self.ShellRuleWF, re.IGNORECASE)
            match = pattern.finditer(_code)
            mlist = list(match)
            wnum = len(mlist)

            writematchstr = ''
            if wnum > 0:
                for m in mlist:
                    writematchstr += m.group()[0:30] + '<br>'

            scanretdict['writenum'] = str(wnum)
            scanretdict['writematch'] = writematchstr[:-2]
            if enum > 0 or wnum > 0:
                scanretdict['filename'] = filepath
                return scanretdict
        return {}
