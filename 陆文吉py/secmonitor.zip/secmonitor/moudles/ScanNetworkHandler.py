#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Date    : 2015-11-12 18:01:32
# @Author  : veng (veng6115@gmail.com)
# @Link    : http://www.veng.cc

import copy
import threading
import time
import traceback


class ScanNetworkHandler(threading.Thread):

    """ monitor network connection """

    def __init__(self, (event_queue, noticehandler)):
        super(ScanNetworkHandler, self).__init__()
        self.daemon = False
        self.whiteiplist = []
        self.whitedict = {}
        self.mailuser = []
        self.queue, self.nt_hd = (event_queue, noticehandler)
        self.splunkport = 30002
        self.sleeptime = 10
        self.nt_hd.log('ScanNetworkHandler', 'step in init.')

    def run(self):
        commandlist = []
        # 检测列表
        cmddict = [{'name': 'nginx', 'grep': 'www', 'egrep': ['^nginx']},
                   {'name': 'hhlyadmin', 'grep': 'hhlyadmin',
                    'egrep': ['^java', '^sshd', '^memcached', 'monitor',
                              '^grep', '^egrep']},
                   {'name': 'root', 'grep': 'root',
                    'egrep': ['^sshd', '^splunkd', '^nginx', '^java',
                              '^grep', '^egrep', '^ntpdate']},
                   {'name': 'zabbix', 'grep': 'zabbix', 'egrep': ['^zabbix']},
                   {'name': 'oracle', 'grep': 'oracle', 'egrep': ['^oracle']},
                   {'name': 'other', 'grep': None,
                    'egrep': ['oracle', 'www', 'root', 'hhlyadmin',
                              'zabbix', '^COMMAND', '^sshd']}
                   ]
        self.whitedict = self.nt_hd.whitedict
        self.whiteiplist = self.nt_hd.whiteiplist

        cmd = 'lsof -Pn -i 4'
        for line in cmddict:
            tmp = ''
            if line['grep'] is not None:
                tmp = '|grep %s' % line['grep']

            egreplst = line['egrep']
            if line['name'] in self.whitedict.keys():
                egreplst += self.whitedict[line['name']]

            tmp = cmd + tmp + '|egrep -v "%s"' % '|'.join(egreplst)
            commandlist.append(tmp)
        retlist_old = []

        namelist = ['user', 'pid', 'procname', 'connection', 'cmd']

        while True:
            try:
                retlist_new = []
                for command in commandlist:
                    outputlist = self.nt_hd.getcommanddata(command)
                    if outputlist:
                        for line in outputlist:
                            tmplist = line.split()
                            if tmplist is not None:
                                retdict = {}
                                retdict['user'] = tmplist[2]
                                retdict['pid'] = tmplist[1]
                                retdict['procname'] = tmplist[0]
                                retdict['connection'] = ''.join(tmplist[8:])
                                dnsconnect = retdict['connection']
                                dnsconnect = dnsconnect[
                                    dnsconnect.rfind('>') + 1:]
                                srcip = dnsconnect[:dnsconnect.rfind(':')]
                                if srcip not in self.whiteiplist:
                                    commandps = 'ps -fww -p %s %s' % (
                                        retdict['pid'], '--no-heading')
                                    tmp = self.nt_hd.getcommanddata(commandps)
                                    if tmp:
                                        retdict['cmd'] = ' '.join(
                                            tmp[0].split()[7:])
                                    else:
                                        retdict['cmd'] = ' '
                                    retlist_new.append(retdict)
                if retlist_old != retlist_new:
                    if retlist_old:
                        tmpretlist = []
                        for line in retlist_new:
                            if line not in retlist_old:
                                tmpretlist.append(line)
                        if tmpretlist:
                            bsendmail = False
                            for linedict in tmpretlist:
                                msg = ''
                                for name in namelist:
                                    msg += ',%s' % linedict[name]
                                self.nt_hd.log('network', msg)
                                bret = self.nt_hd.senddata(msg, self.splunkport)
                                self.nt_hd.log('network', 'status.' + str(bret))
                                if not bret:
                                    bsendmail = True
                            if bsendmail:
                                self.nt_hd.log('network', 'step in sendmail.')
                                self.nt_hd.sendmail(tmpretlist, False)
                retlist_old = copy.deepcopy(retlist_new)
            except:
                msg = traceback.format_exc()
                self.nt_hd.log('ScanNetworkHandler', 'errormsg=%s' % str(msg))
                break
            time.sleep(self.sleeptime)
