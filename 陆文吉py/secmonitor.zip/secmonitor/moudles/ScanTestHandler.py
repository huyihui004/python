#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Date    : 2015-11-12 18:01:32
# @Author  : veng (veng6115@gmail.com)
# @Link    : http://www.veng.cc

import threading
import time
import traceback


class ScanTestHandler(threading.Thread):

    """ monitor network connection """

    def __init__(self, (event_queue, noticehandler)):
        super(ScanTestHandler, self).__init__()
        self.daemon = False
        self.queue, self.nt_hd = (event_queue, noticehandler)
        self.nt_hd.log('ScanTestHandler', 'step in init.')

    def run(self):
        i = 0
        while True:
            # try:
            #     import os
            #     data = os.popen('id').read()
            #     self.nt_hd.log('ScanTestHandler',
            #                    'step in :%d.\t data=%s\n' % (i, str(data)))
            # except Exception, e:
            #     self.nt_hd.log('ScanTestHandler',
            #                    'step in :%d.\t data=%s\n' % (i, str(e)))
            #     data = self.nt_hd.getcommanddata('id')
            #     self.nt_hd.log('ScanTestHandler',
            #                    'step in :%d.\t data=%s\n' % (i, str(data)))
            i = i + 1
            time.sleep(10)
