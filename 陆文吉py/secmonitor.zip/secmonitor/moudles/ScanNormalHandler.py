#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Date    : 2015-11-23 16:04:40
# @Author  : veng (veng6115@gmail.com)
# @Link    : http://www.veng.cc

import threading
import time
import traceback


class ScanNormalHandler(threading.Thread):

    """ normal item check """

    def __init__(self, (event_queue, noticehandler)):
        super(ScanNormalHandler, self).__init__()
        self.daemon = False
        self.queue, self.nt_hd = (event_queue, noticehandler)
        self.splunkport = 30002
        self.sleeptime = 1 * 30 * 60
        self.nt_hd.log('ScanNormalHandler', 'step in init.')

    def run(self):

        pid = self.nt_hd.getprocpid()
        commandline = "ps -o 'rss' -p %d --no-heading" % pid
        threadnumcmd = 'ps -L -p %d|wc -l' % pid
        while True:
            try:
                rssmem = self.nt_hd.getcommanddata(commandline)[0]
                threadnum = self.nt_hd.getcommanddata(threadnumcmd)[0]
                self.nt_hd.log('ScanNormalHandler',
                               'info:  pid=%d,used memory=%sKB, exists threads num=%s' % (pid, rssmem, threadnum))
                if int(rssmem) >= 1 * 1024 * 1024:
                    self.nt_hd.log('ScanNormalHandler',
                                   'killself!  used memory=%sKB' % rssmem)
                    self.nt_hd.kill(pid)
            except:
                msg = traceback.format_exc()
                self.nt_hd.log('ScanNormalHandler', 'errormsg=%s' % str(msg))
                break
            time.sleep(self.sleeptime)
